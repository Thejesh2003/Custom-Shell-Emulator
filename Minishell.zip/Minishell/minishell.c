/*
Title : Minishell
Name : S R Thejesh
Date : 22/05/2025
Description : A Command-Line Interpreter Project
    The Minishell project is a command-line interpreter that aims to replicate the behavior of a basic shell, such as Bash or Zsh. The project's primary goal is to provide a simple and functional shell that allows users to execute external commands, manage processes, and interact with the file system.
*/

#include <stdio.h>
#include "msh.h"
char prompt[20] = "minishell$";   // promt message
char input[30]; //input string
int main()
{
    system("clear");
    scan_input(prompt, input);
    return 0;
}